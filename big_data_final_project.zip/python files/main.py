from random_forest import *

if __name__ == '__main__':

    print("primary more info:")
    primary_print_more_info()

    plot_ptarget()

    print("secondary data info")
    print_more_info()

    plot_test_part()
    plot_poisonous()
    plot_test_part_examples()

    print("random forest")
    splitting_data1()
    splitting_data2()

